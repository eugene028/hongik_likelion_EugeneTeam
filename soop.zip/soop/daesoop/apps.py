from django.apps import AppConfig


class DaesoopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daesoop'
