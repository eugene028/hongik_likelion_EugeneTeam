from email.mime import image
from enum import auto
from tokenize import blank_re
from django.db import models
from datadmodelapp.models import User

class TimeStamp(models.Model):
    create_at = models.DateTimeField(auto_now_add= True)
    create_at = models.DateTimeField(auto_now_add= True)
# Create your models here.
class Post(TimeStamp):
    author = models.ForeignKey(User,null=True,on_delete=models.CASCADE,related_name="post_author")
    image = models.ImageField(blank= True)
    caption = models.TextField(blank= True)
    image_likes = models.ManyToManyField(User,related_name="image_likes_user")
class Comment(TimeStamp):
    author = models.ForeignKey(User,null=True,on_delete=models.CASCADE,related_name="post_author")
    posts = models.ForeignKey(Post,null=True,on_delete=models.CASCADE,related_name="comment_post")
    contents = models.TextField(blank=True,max_length=255)