from django.db import models
from django.urls import reverse
from django.contrib.auth.models import AbstractUser



GENDER_CHOICES = [
    ('M','male'),
    ('F','female'),
    ('C','Custom')
]
# Create your models here.
class User(AbstractUser):
    name = models.CharField(blank= True, max_length=255)

    def get_absolute_url(self):
        return reverse("users:detail", kwargs = {"username" : self.username})

    user_name = models.CharField(blank = True,  max_length=255)
    photo = models.ImageField(blank = True)
    website = models.URLField(blank = True)
    bio = models.TextField(blank = True)
    email = models.EmailField(blank = True,  max_length=255)
    gender = models.CharField(blank = True, choices = GENDER_CHOICES, max_length=255)
    followers = models.ManyToManyField("self")
    following = models.ManyToManyField("self")